<?php
/**
 * @package RSDirectory!
 * @copyright (C) 2013-2014 www.rsjoomla.com
 * @license GPL, http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access.
defined('_JEXEC') or die('Restricted access');

?>

<div class="rsdir">
	<div class="row-fluid">
		<?php echo $this->message; ?>
	</div><!-- .row-fluid -->
</div><!-- .rsdir -->