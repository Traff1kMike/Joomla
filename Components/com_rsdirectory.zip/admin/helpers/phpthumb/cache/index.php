<?php
header('Location: /');
exit;
?>